<?php get_header(); ?>

    <main>
    <!-- Trending Area Start -->
    <div class="trending-area fix">
        <div class="container">
            <div class="trending-main">
                <?php get_template_part('template-parts/home-feature'); ?>

            </div>
        </div>
    </div>
    <!-- Trending Area End -->
        <?php get_template_part('template-parts/top-news'); ?>
        
  <?php get_template_part('template-parts/weekly-news'); ?>
  <?php get_template_part('template-parts/recent-posts'); ?>


  

    </main>
    
   <?php get_footer(); ?>