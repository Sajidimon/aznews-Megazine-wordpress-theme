<footer>
    <!-- Footer Start-->
    <div class="footer-area footer-padding fix">
        <div class="container">
            <div class="row d-flex justify-content-between">

                <div class="col-xl-5 col-lg-5 col-md-7 col-sm-12">

                    <?php 
                        if(is_active_sidebar('footer-1')){
                                dynamic_sidebar('footer-1');
                        }
                    ?>
                </div>

                <div class="col-xl-3 col-lg-3 col-md-4  col-sm-6">

                <?php 
                        if(is_active_sidebar('footer-2')){
                                dynamic_sidebar('footer-2');
                        }
                    ?>
                    
                </div>

                <div class="col-xl-3 col-lg-3 col-md-5 col-sm-6">

                <?php 
                        if(is_active_sidebar('footer-3')){
                                dynamic_sidebar('footer-3');
                        }
                    ?>
                </div>
            </div>
        </div>
    </div>
    <!-- footer-bottom aera -->
    <div class="footer-bottom-area">
        <div class="container">
            <div class="footer-border">
                <div class="row d-flex align-items-center justify-content-between">
                    <div class="col-lg-6">
                        <div class="footer-copy-right">
                            <p>
                                <?php echo wp_kses_post(get_theme_mod('aznews_copyright')); ?>
                            </p>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="footer-menu f-right">
                            <?php wp_nav_menu(
                                array(
                                    'theme_location'    => 'footer-menu',
                                    'fallback_cb'       => false
                                )
                            ); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Footer End-->
</footer>
<?php wp_footer(); ?>
</body>

</html>