<?php

$aznews_recent_post = new WP_Query(
    array(
        'post_type'                => 'post',
        'posts_per_page'           => 9,
        'post__not_in'              => get_option('featured')
    )
);


if ($aznews_recent_post->have_posts()) : ?>
    <!--  Recent Articles start -->
    <div class="recent-articles">
        <div class="container">
            <div class="recent-wrapper">
                <!-- section Tittle -->
                <div class="row">
                    <div class="col-lg-12">
                        <div class="section-tittle mb-30">
                            <h3><?php _e('Recent Articles', 'aznews'); ?></h3>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <?php

                    while ($aznews_recent_post->have_posts()) :
                        $aznews_recent_post->the_post();

                    ?>
                        <div class="col-lg-4">
                            <div class="recent-active dot-style d-flex dot-style">

                                <div class="single-recent mb-100">
                                    <div class="what-img">
                                        <img src="<?php echo wp_get_attachment_url(get_post_thumbnail_id($post->ID)); ?>">
                                    </div>
                                    <div class="what-cap">
                                        <span class="color1"><?php the_category(' '); ?></span>
                                        <h4><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
                                    </div>
                                </div>

                            </div>
                        </div>
                    <?php endwhile; ?>
                </div>
            </div>
        </div>
    </div>
    <!--Recent Articles End -->
<?php endif; ?>