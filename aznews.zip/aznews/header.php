<!doctype html>
<html class="no-js" <?php language_attributes(); ?>>

<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php wp_head(); ?>
</head>

<?php wp_body_open(); ?>
<body <?php body_class(); ?>>

    <header>
        <!-- Header Start -->
        <div class="header-area">
            <div class="main-header ">
                <div class="header-mid d-none d-md-block">
                    <div class="container">
                        <div class="row d-flex align-items-center">

                            <?php if (has_header_image()) {

                            ?>
                                <!-- Logo -->
                                <div class="col-xl-3 col-lg-3 col-md-3">
                                    <div class="logo">
                                        <?php if(has_custom_logo()){
                                                the_custom_logo();
                                        } ?>
                                    </div>
                                </div>


                                <div class="col-xl-9 col-lg-9 col-md-9">
                                    <div class="header-banner f-right ">
                                    <img src="<?php header_image(); ?>">
                                    </div>
                                </div>
                            <?php

                            } else { ?>
                                <!-- Logo -->
                                <div class="col-xl-12 col-lg-12 col-md-12">
                                    <div class="logo">
                                        <?php if(has_custom_logo()){
                                                the_custom_logo();
                                        } ?>
                                    </div>
                                </div>
                            <?php }

                            ?>
                        </div>
                    </div>
                </div>
                <div class="header-bottom header-sticky">
                    <div class="container">
                        <div class="row align-items-center">
                            <div class="col-xl-10 col-lg-10 col-md-12 header-flex">
                                <!-- sticky -->
                                <div class="sticky-logo">
                                    <a href="<?php echo wp_kses_post(home_url()); ?>">
                                        <?php if(has_custom_logo()){
                                                the_custom_logo();
                                        } ?>
                                    </a>
                                </div>
                                <!-- Main-menu -->
                                <div class="main-menu d-none d-md-block">
                                    <nav>

                                        <?php

                                        $navigation = wp_nav_menu(
                                            array(
                                                'theme_location'        => 'top-menu',
                                                'menu_class'            => 'navigation',
                                                'fallback_cb'           => false,
                                                'echo'                  => false
                                            )
                                        );

                                        $navigation = str_replace('sub-menu', 'submenu', $navigation);
                                        echo $navigation;
                                        ?>

                                    </nav>
                                </div>
                            </div>
                            <div class="col-xl-2 col-lg-2 col-md-4">
                                <div class="header-right-btn f-right d-none d-lg-block">
                                    <i class="fas fa-search special-tag"></i>
                                    <div class="search-box">
                                        <?php get_search_form(); ?>
                                    </div>
                                </div>
                            </div>
                            <!-- Mobile Menu -->
                            <div class="col-12">
                                <div class="mobile_menu d-block d-md-none"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Header End -->
    </header>