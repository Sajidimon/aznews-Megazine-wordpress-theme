<?php

function callie_demo_import_files() {
    return array(
      array(
        'import_file_name'             => 'Callie',
        'categories'                   => array( 'News & Blogs', 'Ecommerce' ),
        'local_import_file'            => trailingslashit( get_template_directory() ) . 'inc/demo-content/callie-content.xml',
        'local_import_widget_file'     => trailingslashit( get_template_directory() ) . 'inc/demo-content/callie-widgets.wie',
        'local_import_customizer_file' => trailingslashit( get_template_directory() ) . 'inc/demo-content/callie-customizer.dat',
        'import_preview_image_url'     => 'https://www.it-kothon.com/wp-content/uploads/2020/05/E-commerce-website-template--scaled.jpg',
        'import_notice'                => __( 'After you import this demo, you will have to setup the slider separately.', 'callie' ),
        'preview_url'                  => 'http://www.your_domain.com/my-demo-1',
      ),
      array(
        'import_file_name'             => 'Aznews',
        'categories'                   => array( 'Megazine', 'Blog' ),
        'local_import_file'            => trailingslashit( get_template_directory() ) . 'inc/demo-content/aznews-content.xml',
        'local_import_widget_file'     => trailingslashit( get_template_directory() ) . 'inc/demo-content/aznews-widgets.wie',
        'local_import_customizer_file' => trailingslashit( get_template_directory() ) . 'inc/demo-content/aznews-customizer.dat',
        'import_preview_image_url'     => 'https://www.it-kothon.com/wp-content/uploads/2020/05/Techmarter-Best-selling-products-reviews-buying-guides-techmarter.com-Copy.jpg',
        'import_notice'                => __( 'After you import this demo, you will have to go Settings -> Reading & set Homepage = home & Blogpage = blog.', 'aznews' ),
        'preview_url'                  => 'http://www.your_domain.com/my-demo-2',
      ),
    );
  }
  add_filter( 'pt-ocdi/import_files', 'callie_demo_import_files' );