<?php
the_post();
get_header();
?>

<!--================Blog Area =================-->
<section class="blog_area single-post-area section-padding">
	<div class="container">
		<div class="row">
			<div class="col-lg-8 posts-list">
				<div class="single-post">
					<div class="feature-img">
						<?php the_post_thumbnail('large'); ?>
					</div>
					<div class="blog_details">
						<h2>
							<?php the_title(); ?>
						</h2>
						<ul class="blog-info-link mt-3 mb-4">
							<li><i class="fa fa-user"></i> <?php the_category(' '); ?></li>
							<li><i class="fa fa-comments"></i> <?php comments_number(); ?></li>
						</ul>
						<!-- post content -->
						<div class="section-row">
							<?php

							the_content();
							wp_link_pages();

							?>
						</div>

						<?php 
						_e('Tags :', 'aznews');
						the_tags(' '); 
						?>
						<!-- /post content -->
					</div>
				</div>
				<div class="navigation-top">
					<div class="navigation-area">
						<div class="row">
							<?php $prevPost = get_previous_post(true);
							if ($prevPost) { ?>
								<div class="col-lg-6 col-md-6 col-12 nav-left flex-row d-flex justify-content-start align-items-center">
									<div class="thumb">
										<a href="#">
											<img class="img-fluid" src="<?php echo wp_get_attachment_url(get_post_thumbnail_id($prevPost->ID));  ?>">
										</a>
									</div>
									<div class="arrow">
										<a href="#">
											<span class="lnr text-white ti-arrow-left"></span>
										</a>
									</div>
									<div class="detials">
										<p><?php _e('Prev Post', 'aznews'); ?></p>
										<a href="#">
											<h4><?php previous_post_link('%link', "<p>%title</p>", TRUE); ?></h4>
										</a>
									</div>
								</div>
							<?php }
							$nextPost = get_next_post(true);
							if ($nextPost) { ?>
								<div class="col-lg-6 col-md-6 col-12 nav-right flex-row d-flex justify-content-end align-items-center">
									<div class="detials">
										<p><?php _e('Next Post', 'aznews'); ?></p>
										<a href="#">
											<h4><?php next_post_link('%link', "<p>%title</p>", TRUE); ?></h4>
										</a>
									</div>
									<div class="arrow">
										<a href="#">
											<span class="lnr text-white ti-arrow-right"></span>
										</a>
									</div>
									<div class="thumb">
										<a href="#">
											<img class="img-fluid" src="<?php echo wp_get_attachment_url(get_post_thumbnail_id($nextPost->ID)); ?>">
										</a>
									</div>
								</div>
							<?php } ?>
						</div>
					</div>
				</div>
				<div class="blog-author">
					<div class="media align-items-center">
						<img src="assets/img/blog/author.png" alt="">
						<div class="media-body">
							<a href="#">
								<h4><?php the_author(); ?></h4>
							</a>
							<p><?php the_author_meta('description'); ?></p>
						</div>
					</div>
				</div>
				<!-- post comments -->


				<?php
				if (!post_password_required()) {
					comments_template();
				}
				?>
			</div>
			<?php get_sidebar(); ?>
		</div>
	</div>
</section>
<!--================ Blog Area end =================-->

<?php get_footer(); ?>