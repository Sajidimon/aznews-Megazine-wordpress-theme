
   <?php get_header(); ?>
    <main>
        <!-- About US Start -->
        <div class="about-area">
            <div class="container">
                   <div class="row">
                        <div class="col-lg-8">
                            <!-- Trending Tittle -->
                                    <div class="about-right mb-90">
                                        <div class="section-tittle mb-30 pt-30">
                                            <h3><?php the_title(); ?></h3>
                                        </div>
                                        <div class="about-prea">
                                            <?php the_content(); ?>
                                        </div>
                                    </div>
                        </div>
                        <div class="col-lg-4">
                        <?php 
                        if(is_active_sidebar('front_right_sidebar')){
                            dynamic_sidebar('front_right_sidebar');
                        }
                    ?>
                        </div>
                   </div>
            </div>
        </div>
        <!-- About US End -->
    </main>
   <?php get_footer(); ?>