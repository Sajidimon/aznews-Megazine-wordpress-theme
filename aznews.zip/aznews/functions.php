<?php

function aznews_setup()
{

	load_theme_textdomain('aznews', get_template_directory() . '/languages');
	add_theme_support('widgets');
	add_theme_support('post-thumbnails');
	add_theme_support('automatic-feed-links');
	add_theme_support('custom-header');
	add_theme_support('custom-background');
	add_theme_support('title-tag');
	add_editor_style();
	add_theme_support('custom-logo', array(
		'height'		=> 250,
		'width'			=> 250,
		'flex-width'	=> true,
		'flex-height'	=> true,
	));

	if ( ! isset( $content_width ) ) $content_width = 1349;

	add_image_size('aznews_image', 700, 467, true);
	add_image_size('aznews_cat_image', 1920, 480, true);


	register_nav_menus(
		array(
			'top-menu'		=> __('Top menu', 'aznews'),
			'footer-menu'	=> __('Footer menu', 'aznews')

		)
	);
}

add_action('after_setup_theme', 'aznews_setup');


/**
 * Register widget area.
 *
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
 */
function aznews_widgets_init()
{
	register_sidebar(
		array(
			'name'          => esc_html__('Blog Right sidebar', 'aznews'),
			'id'            => 'blog_right_sidebar',
			'description'   => esc_html__('Widgets in this area will be displayed for blog right sidebar.', 'aznews'),
			'before_widget' => '<aside class="single_sidebar_widget">',
			'after_widget'  => '</aside>',
			'before_title'  => '<h4 class="widget_title">',
			'after_title'   => '</h4>',
		)
	);
	register_sidebar(
		array(
			'name'          => esc_html__('Footer widgets area one', 'aznews'),
			'id'            => 'footer-1',
			'description'   => esc_html__('Widgets in this area will be displayed in the first column in the footer.', 'aznews'),
			'before_widget' => '<div class="single-footer-caption">',
			'after_widget'  => '</div>',
			'before_title'  => '<div class="footer-tittle"><h4>',
			'after_title'   => '</h4></div>',
		)
	);
	register_sidebar(
		array(
			'name'          => esc_html__('Footer widgets area two', 'aznews'),
			'id'            => 'footer-2',
			'description'   => esc_html__('Widgets in this area will be displayed in the second column in the footer.', 'aznews'),
			'before_widget' => '<div class="single-footer-caption">',
			'after_widget'  => '</div>',
			'before_title'  => '<div class="footer-tittle"><h4>',
			'after_title'   => '</h4></div>',
		)
	);
	register_sidebar(
		array(
			'name'          => esc_html__('Footer widgets area three', 'aznews'),
			'id'            => 'footer-3',
			'description'   => esc_html__('Widgets in this area will be displayed in the third column in the footer.', 'aznews'),
			'before_widget' => '<div class="single-footer-caption">',
			'after_widget'  => '</div>',
			'before_title'  => '<div class="footer-tittle"><h4>',
			'after_title'   => '</h4></div>',
		)
	);
	
}
add_action('widgets_init', 'aznews_widgets_init');


add_filter('acf/settings/show_admin', '__return_false');

function aznews_pagination(){
	global $wp_query;
	$pagination = paginate_links(array(
		'current'		=>max(1, get_query_var('paged')),
		'total'			=>$wp_query->max_num_pages,
		'type'			=>'list'
	));

	$pagination = str_replace('page-numbers', 'pagination', $pagination);
	$pagination = str_replace('pagination current', 'page-item active', $pagination);
	$pagination = str_replace('span', 'a', $pagination);
	echo wp_kses_post($pagination);

	
}

/**
 * Enqueue scripts and styles.
 */
function aznews_scripts()
{


	wp_enqueue_style('bootstrap', get_template_directory_uri() . '/inc/assets/css/bootstrap.min.css', null, true, 'all');
	wp_enqueue_style('carousel', get_template_directory_uri() . '/inc/assets/css/owl.carousel.min.css', null, true, 'all');
	wp_enqueue_style('flaticon', get_template_directory_uri() . '/inc/assets/css/flaticon.css', null, true, 'all');
	wp_enqueue_style('slicknav', get_template_directory_uri() . '/inc/assets/css/slicknav.css', null, true, 'all');
	wp_enqueue_style('animate', get_template_directory_uri() . '/inc/assets/css/animate.min.css', null, true, 'all');
	wp_enqueue_style('magnific-popup', get_template_directory_uri() . '/inc/assets/css/magnific-popup.css', null, true, 'all');
	wp_enqueue_style('fontawesome-all', get_template_directory_uri() . '/inc/assets/css/fontawesome-all.min.css', null, true, 'all');
	wp_enqueue_style('themify-icons', get_template_directory_uri() . '/inc/assets/css/themify-icons.css', null, true, 'all');
	wp_enqueue_style('slick', get_template_directory_uri() . '/inc/assets/css/slick.css', null, true, 'all');
	wp_enqueue_style('nice-select', get_template_directory_uri() . '/inc/assets/css/nice-select.css', null, true, 'all');
	wp_enqueue_style('main-style', get_template_directory_uri() . '/inc/assets/css/main-style.css', null, true, 'all');
	wp_enqueue_style('responsive', get_template_directory_uri() . '/inc/assets/css/responsive.css', null, true, 'all');
	wp_enqueue_style("style-css", get_stylesheet_uri());



	wp_enqueue_script('modernizr', get_template_directory_uri() . '/inc/assets/js/vendor/modernizr-3.5.0.min.js',null, true, true);
	wp_enqueue_script('popper', get_template_directory_uri() . '/inc/assets/js/popper.min.js',array('jquery'), true, true);
	wp_enqueue_script('bootstrap', get_template_directory_uri() . '/inc/assets/js/bootstrap.min.js',array('jquery'), true, true);
	wp_enqueue_script('slicknav', get_template_directory_uri() . '/inc/assets/js/jquery.slicknav.min.js',array('jquery'), true, true);
	wp_enqueue_script('carousel', get_template_directory_uri() . '/inc/assets/js/owl.carousel.min.js',array('jquery'), true, true);
	wp_enqueue_script('slick', get_template_directory_uri() . '/inc/assets/js/slick.min.js',array('jquery'), true, true);
	wp_enqueue_script('gijgo', get_template_directory_uri() . '/inc/assets/js/gijgo.min.js',array('jquery'), true, true);
	wp_enqueue_script('wow', get_template_directory_uri() . '/inc/assets/js/wow.min.js',array('jquery'), true, true);
	wp_enqueue_script('animated', get_template_directory_uri() . '/inc/assets/js/animated.headline.js',array('jquery'), true, true);
	wp_enqueue_script('magnific-popup', get_template_directory_uri() . '/inc/assets/js/jquery.magnific-popup.js',array('jquery'), true, true);
	wp_enqueue_script('jquery.ticker', get_template_directory_uri() . '/inc/assets/js/jquery.ticker.js',array('jquery'), true, true);
	wp_enqueue_script('site', get_template_directory_uri() . '/inc/assets/js/site.js',array('jquery'), true, true);
	wp_enqueue_script('scrollUp', get_template_directory_uri() . '/inc/assets/js/jquery.scrollUp.min.js',array('jquery'), true, true);
	wp_enqueue_script('nice-select', get_template_directory_uri() . '/inc/assets/js/jquery.nice-select.min.js',array('jquery'), true, true);
	wp_enqueue_script('sticky', get_template_directory_uri() . '/inc/assets/js/jquery.sticky.js',array('jquery'), true, true);
	wp_enqueue_script('contact', get_template_directory_uri() . '/inc/assets/js/contact.js',array('jquery'), true, true);
	wp_enqueue_script('form', get_template_directory_uri() . '/inc/assets/js/jquery.form.js',array('jquery'), true, true);
	wp_enqueue_script('validate', get_template_directory_uri() . '/inc/assets/js/jquery.validate.min.js',array('jquery'), true, true);
	wp_enqueue_script('mail-script', get_template_directory_uri() . '/inc/assets/js/mail-script.js',array('jquery'), true, true);
	wp_enqueue_script('ajaxchimp', get_template_directory_uri() . '/inc/assets/js/jquery.ajaxchimp.min.js',array('jquery'), true, true);
	wp_enqueue_script('plugins', get_template_directory_uri() . '/inc/assets/js/plugins.js',array('jquery'), true, true);
	wp_enqueue_script('main', get_template_directory_uri() . '/inc/assets/js/main.js',array('jquery'), true, true);


	if (is_singular() && comments_open() && get_option('thread_comments')) {
		wp_enqueue_script('comment-reply');
	}
}
add_action('wp_enqueue_scripts', 'aznews_scripts');

function aznews_search_form($form)
{
	$placeholder = __('Enter your search...', 'aznews');
	$search_form = <<<FORM
	<form>
		<input class="input" name="s" placeholder="{$placeholder}">
	</form>
	FORM;
	
	return $search_form;
}

add_filter("get_search_form", "aznews_search_form");

/**
 * Implement tgm plugin activation features.
 */
require_once get_template_directory() . '/inc/tgm/tgm.php';
/**
 * Implement Metaboxes features.
 */
require_once get_template_directory() . '/inc/metabox/metaboxes.php';
/**
 * Implement Theme options features.
 */
require_once get_template_directory() . '/inc/customizer/customizer.php';


require_once get_template_directory() . '/inc/demo-config.php';
