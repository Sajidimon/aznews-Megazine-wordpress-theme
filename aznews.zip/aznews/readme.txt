Aznews- Official wordpress theme for any kind of megazine or blog website

Initial release: 
version: 1.0