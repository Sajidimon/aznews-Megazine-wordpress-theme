<?php get_header(); ?>

<main>
    <!-- Whats New Start -->
    <section class="whats-news-area pt-50 pb-20">
        <div class="container">
            <div class="row">
                <div class="col-lg-8">
                    <div class="row">
                        <div class="col-12">
                            <!-- Nav Card -->
                            <div class="tab-content" id="nav-tabContent">
                                <!-- card one -->
                                <div class="tab-pane fade show active" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab">
                                    <div class="whats-news-caption">
                                        <div class="row">
                                            <?php

                                            while (have_posts()) :
                                                the_post();
                                            ?>
                                                <div class="col-lg-6 col-md-6">
                                                    <div class="single-what-news mb-100">
                                                        <div class="what-img">
                                                            <img src="<?php echo wp_get_attachment_url(get_post_thumbnail_id($post->ID)); ?>">
                                                        </div>
                                                        <div class="what-cap">
                                                            <span class="color1"><?php the_category(' '); ?></span>
                                                            <h4><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php endwhile; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- End Nav Card -->
                        </div>
                    </div>
                </div>
                <?php get_sidebar(); ?>
            </div>
        </div>
    </section>
    <!-- Whats New End -->


    <!--Start pagination -->
    <nav class="blog-pagination justify-content-center d-flex">

        <?php aznews_pagination(); ?>

    </nav>
    <!-- End pagination  -->
</main>

<?php get_footer(); ?>